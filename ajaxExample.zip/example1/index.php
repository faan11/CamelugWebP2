<!DOCTYPE HTML>
<html>
	<head>
 	<script type="text/javascript" src="/js/jquery.min.js">
	</script>		
	<script type="text/javascript">
	function my(){
		var request = $.ajax({
			url: "request.php",
			method: "POST",
			data: { text: $("#text").val() },
			dataType: "html"
		});
		request.done(function( msg ) {
			$( "#log" ).html($("#log").html()+"<br>"+ msg );
		});
		request.fail(function( jqXHR, textStatus ) { 
			alert( "Request failed: " + textStatus ); 
		});
	} 
	</script>
	
	</head>

	<body >
		<div id="form">
			<input type="text" id="text">
		  	<input type="submit" value="Ok send the text" onclick="my()">		
		</div>
		<h3> Server Answer</h3>
		<div id="log">
		</div>
	</body>

	

</html>
