<?php
echo $_POST["text"]."... certo se no.. non ti rispondevo";

?>
