<!DOCTYPE HTML>
<html>
	<head>
 	<script type="text/javascript" src="js/jquery.min.js">
	</script>		
	<script type="text/javascript">
	function my(){
		var request = $.ajax({
			url: "script.php",
			method: "POST",
			data: { id : 1 },
			dataType: "html"
		});
		request.done(function( msg ) {
			$( "#log" ).html( msg );
		});
		request.fail(function( jqXHR, textStatus ) { 
			alert( "Request failed: " + textStatus ); 
		});
	} 
	</script>
	
	</head>

	<body onLoad="my()">
	</body>

	

</html>
