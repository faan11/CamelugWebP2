@extends("authors.list")


@section("content")

@show
