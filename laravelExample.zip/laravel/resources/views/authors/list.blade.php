<!DOCTYPE HTML>
<html>
<head>

</head>


<body>
	@foreach($authors as $author)
		<h3> {{ $author->name }} </h3>
	@endforeach
</body>



</html>
